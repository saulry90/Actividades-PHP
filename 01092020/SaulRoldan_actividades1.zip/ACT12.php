<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ACT12</title>
</head>
<body>
    <h1>Actividad 1-2 (Meeting)</h1>
    <?php
    $nombrechico="Saúl";
    $nombrechica="Diana";
    $nacimiento=1990;
    echo "A ".$nombrechico." le gusta ".$nombrechica.".";
    echo "<p>Me llamo ".$nombrechico." y nací en ".$nacimiento.". Por lo tanto tengo ".(2020-$nacimiento)." años.</p>";
    ?>
</body>
</html>