<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ACT11</title>
</head>
<body>
    <h1>Actividad 1-1 (Calculando)</h1>
    <?php
    $num1=5;
    $num2=7;
    echo "<p>El resultado es ".($num1+$num2)."</p>"; // suma
    echo "<p>El resultado es ".($num1/$num2)."</p>"; // división
    echo "<p>El resultado es ".($num1**$num2)."</p>"; // potencia
    echo "<p>El resultado es ".($num1%$num2)."</p>"; // módulo
    echo "<p>El resultado es ".($num1*$num2)."</p>"; // multiplicación
    echo "<p>El resultado es ".($num1-$num2)."</p>"; // resta
    ?>
</body>
</html>